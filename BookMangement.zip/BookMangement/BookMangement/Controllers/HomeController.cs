using BookMangement.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Net.Mail;
using System.Net;
using System.Text;
using Microsoft.Extensions.Configuration;
using System.Xml.Linq;

namespace BookMangement.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _configuration;

        public HomeController(ILogger<HomeController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }
        //����
        public IActionResult Index()
        {
            HttpContext.Session.SetString("uid", "1");
            string type = "All";
            DBmanager dbManager = new DBmanager(_configuration);
            List<Books> books = dbManager.GetBooks(type);
            ViewBag.title = "�Ҧ����y All";
            return View(books);
        }
        [HttpPost]
        public IActionResult Index(string type)
        {
            List<Books> books = new List<Books>();
            string BookTitle = "";
            if (type == "Search")
            {
                BookTitle = Request.Form["BookTitle"];
                DBmanager dbManager = new DBmanager(_configuration);
                books = dbManager.QueryBook(BookTitle);
                if (books == null || books.Count == 0)
                {
                    ViewBag.Message = "�S�����ŦX�����y�A�Э��s�j���I";
                    ViewBag.title = "�d�L���y";
                    return View();
                }
            }
            else
            {
                DBmanager dbManager = new DBmanager(_configuration);
                books = dbManager.GetBooks(type);
            }
            if (type == "All")
            {
                ViewBag.title = "�Ҧ����y All";
            }
            else if(type == "Transaction")
            {
                ViewBag.title = "������y Transaction";
            }
            else if (type == "Exchange")
            {
                ViewBag.title = "�洫���y Exchange";
            }
            else if (type == "Rent")
            {
                ViewBag.title = "������y Rent";
            }
            else if (type == "Search")
            {
                if (BookTitle == "")
                {
                    ViewBag.title = "�Ҧ����y All";
                }
                else
                {
                    ViewBag.title = $"���y�W��: {BookTitle}";
                }
            }
            return View(books); //�^�ǵ��G
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(string txtEmail)
        {
            // �ϥ� Google Mail Server �o�H
            string GoogleID = "a3812360@gmail.com"; //Google �o�H�b��
            string TempPwd = "iwxwuipiqqolbows"; //���ε{���K�X
            string ReceiveMail = "s1101677@mail.yzu.edu.tw"; //�����H�c

            string SmtpServer = "smtp.gmail.com";
            int SmtpPort = 587;
            MailMessage mms = new MailMessage();
            mms.From = new MailAddress(GoogleID);
            mms.Subject = "�H��D�D";
            mms.Body = "�H�󤺮e";
            mms.IsBodyHtml = true;
            mms.SubjectEncoding = Encoding.UTF8;
            mms.To.Add(new MailAddress(ReceiveMail));
            using (SmtpClient client = new SmtpClient(SmtpServer, SmtpPort))
            {
                client.EnableSsl = true;
                client.Credentials = new NetworkCredential(GoogleID, TempPwd);//�H�H�b�K 
                client.Send(mms); //�H�X�H��
            }
            return View();
        }
    }
}
