﻿using BookMangement.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System;

namespace BookMangement.Controllers
{
    public class BookController : Controller
    {
        private readonly ILogger<BookController> _logger;
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _environment;
        public BookController(ILogger<BookController> logger, IConfiguration configuration, IWebHostEnvironment environment)
        {
            _logger = logger;
            _configuration = configuration;
            _environment = environment;
        }

        public IActionResult Creat()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Creat(Books books, IFormFile myimg)
        {
            if (ModelState.IsValid)
            {
                if (myimg != null && myimg.Length > 0)
                {
                    string uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
                    string uniqueFileName = Guid.NewGuid().ToString() + "_" + myimg.FileName;
                    string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        myimg.CopyTo(fileStream);
                    }

                    // 儲存圖片路徑到資料庫
                    books.Image = uniqueFileName;
                }

                DBmanager dbmanager = new DBmanager(_configuration);
                try
                {
                    dbmanager.Creat(books);
                    TempData["message"] = "新增成功!";
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                    return RedirectToAction("Index", "Home");
                }
            }
            return View(books);
        }
        [HttpPost]
        public JsonResult Collect(int bookId)
        {
            try
            {
                DBmanager dbmanager = new DBmanager(_configuration);
                Books book = new Books { Id = bookId };
                var newId = dbmanager.CreatCollect(book);

                if (newId.HasValue)
                {
                    return Json(new { success = true, message = "已加入收藏!" });
                }
                else
                {
                    return Json(new { success = false, message = "收藏操作失敗!" });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"發生錯誤: {ex.Message}" });
            }
        }
        public IActionResult Message()
        {
            return View();
        }
        public IActionResult Contact(int Userid, int Bookid)
        {
            // 取得資料庫連接字串
            string ConnStr = _configuration.GetConnectionString("Database")
                             ?? throw new InvalidOperationException("Connection string 'Database' not found.");

            string strSql = @"
                            SELECT 
                                Book.Title AS BookName, 
                                Users.Name AS UserName,
                                Image,
                                Status,
                                Price
                            FROM Book
                            LEFT JOIN Users ON Book.User_Id = Users.Id
                            WHERE Book.Id = @BookId";

            using (var connection = new SqlConnection(ConnStr))
            {
                // 建立 SQL 指令
                var command = new SqlCommand(strSql, connection);
                command.Parameters.AddWithValue("@BookId", Bookid);

                connection.Open(); // 開啟資料庫連接

                // 執行查詢
                using (var reader = command.ExecuteReader())
                {
                    if (reader.HasRows && reader.Read())
                    {
                        ViewBag.BookName = reader["BookName"]?.ToString() ?? "未知書名";
                        ViewBag.UserName = reader["UserName"]?.ToString() ?? "未知使用者";
                        ViewBag.Image = reader["Image"]?.ToString() ?? "";
                        if (reader["Status"].ToString()== "Transaction")
                        {
                            ViewBag.Status = "交易";
                        }
                        else if (reader["Status"].ToString() == "Exchange")
                        {
                            ViewBag.Status = "交換";
                        }
                        else if (reader["Status"].ToString() == "Rent")
                        {
                            ViewBag.Status = "租賃";
                        }
                        ViewBag.Price = reader["Price"]?.ToString() ?? "";
                    }
                    else
                    {
                        ViewBag.BookName = "未知書名";
                        ViewBag.UserName = "未知使用者";
                    }
                }
            }
            ViewBag.UserId = Userid;
            ViewBag.BookId = Bookid;

            return View();
        }
    }
}
