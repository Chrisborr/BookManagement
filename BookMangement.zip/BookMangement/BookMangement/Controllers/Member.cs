﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Security.Cryptography;
using System.Text;
using test.Models;

namespace BookMangement.Controllers
{
    public class Member : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly string ConnStr;
        public Member(IConfiguration configuration)
        {
            _configuration = configuration;
            ConnStr = configuration.GetConnectionString("Database")
                     ?? throw new InvalidOperationException("Connection string 'Database' not found.");
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }
        /// <summary>
        /// 執行登入
        /// </summary>
        /// <param name="inModel"></param>
        /// <returns></returns>
        public async Task<IActionResult> DoLogin(DoLoginIn inModel)
        {
            DoLoginOut outModel = new DoLoginOut();

            // 檢查輸入資料
            if (string.IsNullOrEmpty(inModel.User_Id) || string.IsNullOrEmpty(inModel.User_Password))
            {
                outModel.ErrMsg = "請輸入資料";
                return Json(outModel);
            }

            try
            {
                string ConnStr = _configuration.GetConnectionString("Database")
                                 ?? throw new InvalidOperationException("Connection string 'Database' not found.");

                using (var conn = new SqlConnection(ConnStr))
                {
                    await conn.OpenAsync();

                    // 將密碼轉為 SHA256 雜湊運算(不可逆)
                    string salt = inModel.User_Id.Length > 0
                        ? inModel.User_Id.Substring(0, 1).ToLower()
                        : throw new InvalidOperationException("帳號格式錯誤"); // 增加安全性檢查

                    using (SHA256 sha256 = SHA256.Create())
                    {
                        byte[] bytes = Encoding.UTF8.GetBytes(salt + inModel.User_Password); // 密碼鹽及原密碼組合
                        byte[] hash = sha256.ComputeHash(bytes);

                        StringBuilder result = new StringBuilder();
                        foreach (byte b in hash)
                        {
                            result.Append(b.ToString("X2"));
                        }

                        string CheckPwd = result.ToString(); // 雜湊運算後密碼

                        // 檢查帳號、密碼是否正確
                        string sql = @"
                                        SELECT Id
                                        FROM Users
                                        WHERE Account = @Account AND Password = @User_Password";
                        using (var cmd = new SqlCommand(sql, conn))
                        {
                            // 使用參數化填值
                            cmd.Parameters.AddWithValue("@Account", inModel.User_Id);
                            cmd.Parameters.AddWithValue("@User_Password", CheckPwd); // 雜湊運算後密碼

                            var uid = await cmd.ExecuteScalarAsync(); // 執行查詢並取得結果
                            if (uid != null)
                            {
                                // 有查詢到資料，表示帳號密碼正確
                                HttpContext.Session.SetString("uid", uid.ToString());
                                outModel.ResultMsg = "登入成功";
                            }
                            else
                            {
                                // 查無資料，帳號或密碼錯誤
                                outModel.ErrMsg = "帳號或密碼錯誤";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // 捕捉例外錯誤並記錄
                outModel.ErrMsg = "系統發生錯誤，請稍後再試。";
                // 可以加入記錄日誌的功能，例如：
                // _logger.LogError(ex, "登入發生錯誤");
            }

            // 輸出 JSON
            return Json(outModel);
        }

        public async Task<IActionResult> DoRegister(DoRegisterIn inModel)
        {
            DoRegisterOut outModel = new DoRegisterOut();

            // 檢查輸入資料
            if (string.IsNullOrEmpty(inModel.User_Id) ||
                string.IsNullOrEmpty(inModel.User_Password) ||
                string.IsNullOrEmpty(inModel.User_Name) ||
                string.IsNullOrEmpty(inModel.User_Email))
            {
                outModel.ErrMsg = "請輸入資料";
                return Json(outModel);
            }

            try
            {
                string connStr = _configuration.GetConnectionString("Database")
                                 ?? throw new InvalidOperationException("Connection string 'Database' not found.");

                using (var conn = new SqlConnection(connStr))
                {
                    await conn.OpenAsync();

                    // 檢查帳號是否已存在
                    string sqlCheck = "SELECT COUNT(1) FROM Users WHERE Id = @User_Id";
                    using (var cmdCheck = new SqlCommand(sqlCheck, conn))
                    {
                        cmdCheck.Parameters.AddWithValue("@User_Id", inModel.User_Id);

                        int userExists = (int)await cmdCheck.ExecuteScalarAsync();
                        if (userExists > 0)
                        {
                            outModel.ErrMsg = "此登入帳號已存在";
                            return Json(outModel);
                        }
                    }

                    // 密碼使用 SHA256 雜湊運算
                    string salt = inModel.User_Id.Length > 0
                        ? inModel.User_Id.Substring(0, 1).ToLower()
                        : throw new InvalidOperationException("帳號格式錯誤");

                    using (SHA256 sha256 = SHA256.Create())
                    {
                        byte[] bytes = Encoding.UTF8.GetBytes(salt + inModel.User_Password);
                        byte[] hash = sha256.ComputeHash(bytes);

                        StringBuilder result = new StringBuilder();
                        foreach (byte b in hash)
                        {
                            result.Append(b.ToString("X2"));
                        }

                        string hashedPassword = result.ToString();

                        // 新增資料
                        string sqlInsert = @"
                    INSERT INTO Users (Account,Password, Name, Email)
                    VALUES (@Account,@Password, @Name, @Email)";
                        using (var cmdInsert = new SqlCommand(sqlInsert, conn))
                        {
                            cmdInsert.Parameters.AddWithValue("@Account", inModel.User_Id);
                            cmdInsert.Parameters.AddWithValue("@Password", hashedPassword);
                            cmdInsert.Parameters.AddWithValue("@Name", inModel.User_Name);
                            cmdInsert.Parameters.AddWithValue("@Email", inModel.User_Email);

                            await cmdInsert.ExecuteNonQueryAsync();
                        }
                    }
                }

                outModel.ResultMsg = "註冊完成";
            }
            catch (Exception ex)
            {
                // 捕捉例外並記錄到伺服器日誌
                outModel.ErrMsg = "系統發生錯誤，請稍後再試。";
                // 例如：_logger.LogError(ex, "註冊過程發生錯誤");
            }

            return Json(outModel);
        }
    }
}
