﻿using System.ComponentModel.DataAnnotations;

namespace BookMangement.Models
{
    public class Books
    {
        [Key] // 主鍵標註
        public int Id { get; set; }

        public int User_Id { get; set; }

        [Required(ErrorMessage = "請輸入書籍標題")]
        [StringLength(100, ErrorMessage = "標題長度不得超過 100 個字元")]
        public string Title { get; set; }

        [Required(ErrorMessage = "請輸入作者名稱")]
        [StringLength(50, ErrorMessage = "作者名稱長度不得超過 50 個字元")]
        public string Author { get; set; }

        [Required(ErrorMessage = "請選擇書籍狀態")]
        public string Condition { get; set; }

        [Required(ErrorMessage = "請輸入價格")]
        [Range(1, int.MaxValue, ErrorMessage = "價格必須大於 0")]
        public int Price { get; set; }

        [Required(ErrorMessage = "請選擇書籍類別")]
        public string Category { get; set; }

        [Required(ErrorMessage = "請選擇書籍狀態")]
        public string Status { get; set; }
        [Required(ErrorMessage = "請上傳圖片")]
        public string Image { get; set; } 
        public string Introduction { get; set; } // 非必填
        public string Memo { get; set; } // 非必填
    }
}
