﻿using System.ComponentModel.DataAnnotations;
namespace BookMangement.Models
{
    public class Messages
    {
        [Key] // 主鍵標註
        public int Id { get; set; }
        public string SenderId { get; set; }
        public string ReceiverId { get; set; }
        public string Message { get; set; }
        public string Timestamp { get; set; }
        public string Type { get; set; }
        public string sendToID { get; set; }
        public string UserName { get; set; }
    }
}
