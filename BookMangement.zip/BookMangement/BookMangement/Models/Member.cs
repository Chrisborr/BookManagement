﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace test.Models
{
    public class Member
    {
        
    }

    /// <summary>
    /// 註冊參數
    /// </summary>
    public class DoRegisterIn
    {
        public string User_Id { get; set; }
        public string User_Password { get; set; }
        public string User_Name { get; set; }
        public string User_Email { get; set; }
    }

    /// <summary>
    /// 註冊回傳
    /// </summary>
    public class DoRegisterOut
    {
        public string ErrMsg { get; set; }
        public string ResultMsg { get; set; }
    }

    /// <summary>
    /// 登入參數
    /// </summary>
    public class DoLoginIn
    {
        public string User_Id { get; set; }
        public string User_Password { get; set; }
    }

    /// <summary>
    /// 登入回傳
    /// </summary>
    public class DoLoginOut
    {
        public string ErrMsg { get; set; }
        public string ResultMsg { get; set; }
    }

    /// <summary>
    /// 取得個人資料回傳
    /// </summary>
    public class GetUserProfileOut
    {
        public string ErrMsg { get; set; }
        public string User_Id { get; set; }
        public string User_Name { get; set; }
        public string User_Email { get; set; }
    }

    /// <summary>
    /// 修改個人資料參數
    /// </summary>
    public class DoEditProfileIn
    {
        public string User_Name { get; set; }
        public string User_Email { get; set; }
    }

    /// <summary>
    /// 修改個人資料回傳
    /// </summary>
    public class DoEditProfileOut
    {
        public string ErrMsg { get; set; }
        public string ResultMsg { get; set; }
    }

    /// <summary>
    /// 修改密碼參數
    /// </summary>
    public class DoEditPwdIn
    {
        public string NewUser_Password { get; set; }
        public string CheckUser_Password { get; set; }
    }

    /// <summary>
    /// 修改密碼回傳
    /// </summary>
    public class DoEditPwdOut
    {
        public string ErrMsg { get; set; }
        public string ResultMsg { get; set; }
    }


    /// <summary>
    /// [寄送驗證碼]參數
    /// </summary>
    /// <summary>
    /// [寄送驗證碼]參數
    /// </summary>
    public class SendMailTokenIn
    {
        public string User_Id { get; set; }
    }

    /// <summary>
    /// [寄送驗證碼]回傳
    /// </summary>
    public class SendMailTokenOut
    {
        public string ErrMsg { get; set; }
        public string ResultMsg { get; set; }
    }

    public class VerifyCodeIn
    {
        public string VerificationCode { get; set; }
    }

    public class VerifyCodeOut
    {
        public string ResultMsg { get; set; }
        public string ErrMsg { get; set; }
    }


    /// <summary>
    /// [重設密碼]參數
    /// </summary>
    public class DoResetPwdIn
    {
        public string NewUser_Password { get; set; }
        public string CheckUser_Password { get; set; }
    }

    /// <summary>
    /// [重設密碼]回傳
    /// </summary>
    public class DoResetPwdOut
    {
        public string ErrMsg { get; set; }
        public string ResultMsg { get; set; }
    }
}