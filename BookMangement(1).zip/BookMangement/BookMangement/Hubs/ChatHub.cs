﻿using BookMangement.Controllers;
using BookMangement.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Data.SqlClient;
using static System.Reflection.Metadata.BlobBuilder;

namespace CoreMVC_SignalR_Chat.Hubs
{
    public class ChatHub : Hub
    {
        public static Dictionary<string, string> UserConnections = new Dictionary<string, string>();

        // 用戶連線 ID 列表
        public static List<string> ConnIDList = new List<string>();
        private readonly IConfiguration _configuration;
        private readonly string ConnStr;
        public ChatHub(IConfiguration configuration)
        {
            _configuration = configuration;
            ConnStr = configuration.GetConnectionString("Database")
                     ?? throw new InvalidOperationException("Connection string 'Database' not found.");
        }

        /// <summary>
        /// 連線事件
        /// </summary>
        /// <returns></returns>
        public override async Task OnConnectedAsync()
        {
            var httpContext = Context.GetHttpContext();
            string uid = httpContext.Session.GetString("uid");

            if (!string.IsNullOrEmpty(uid))
            {
                lock (UserConnections)
                {
                    UserConnections[uid] = Context.ConnectionId;
                }
            }

            // 廣播更新
            //await Clients.All.SendAsync("UpdList", UserConnections.Keys);
            await base.OnConnectedAsync();
        }

        /// <summary>
        /// 離線事件
        /// </summary>
        /// <param name="ex"></param>
        /// <returns></returns>
        public override async Task OnDisconnectedAsync(Exception? exception)
        {
            var httpContext = Context.GetHttpContext();
            string uid = httpContext.Session.GetString("uid");

            if (!string.IsNullOrEmpty(uid))
            {
                lock (UserConnections)
                {
                    UserConnections.Remove(uid);
                }
            }

            // 廣播更新
            //await Clients.All.SendAsync("UpdList", UserConnections.Keys);
            await base.OnDisconnectedAsync(exception);
        }

        /// <summary>
        /// 傳遞訊息
        /// </summary>
        /// <param name="user"></param>
        /// <param name="message"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task SendMessage(string selfID, string message, string sendToID, int OrderID, int BookID)
        {
            DBmanager dbmanager = new DBmanager(_configuration);
            var httpContext = Context.GetHttpContext();
            var connectionId = UserConnections.ContainsKey(sendToID) ? UserConnections[sendToID] : null;
            // 發送給指定用戶
            if (UserConnections.ContainsKey(sendToID) && !string.IsNullOrEmpty(connectionId))
            {
                    // 發送訊息給目標用戶
                    await Clients.All.SendAsync("UpdContent", new { message = message, timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), sendToID = sendToID });
                    Console.WriteLine($"Message sent to user {sendToID} with connection ID {connectionId}");
            }
            else
            {
                Console.WriteLine($"User {sendToID} is not connected.");
            }

            // 將聊天記錄存入資料庫
            try
            {
                await dbmanager.CreatMessageAsync(httpContext.Session.GetString("uid"), sendToID, message, BookID, OrderID);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving message to database: {ex}");
                throw; // 可選：回傳錯誤給前端
            }
        }
        public async Task<List<Messages>> GetChatHistory(string receiverId)
        {
            var httpContext = Context.GetHttpContext();
            string ConnStr = _configuration.GetConnectionString("Database")
                     ?? throw new InvalidOperationException("Connection string 'Database' not found.");
            var chatMessages = new List<Messages>();
            string strSql = @"
                    SELECT Messages.* ,u1.Name as SenderName,u2.Name as ReceiverName,isnull(Image,'') as[Image],
                            isnull(Book.Title,'')as [BookName],isnull(Status,'') as[Status],[Transaction].Place,[Transaction].IsCheckOrder
                    FROM Messages
                    join Users u1 on u1.Id = Messages.SenderId
                    join Users u2 on u2.Id = Messages.ReceiverId
                    left join Book on Book.Id = Messages.BookID
                    left join [Transaction] on OrderID = [Transaction].Id
                    WHERE (SenderId = @UserId and ReceiverId = @receive) or (SenderId = @receive and ReceiverId = @UserId)
                    ORDER BY Id ";

            using (var connection = new SqlConnection(ConnStr))
            {
                var command = new SqlCommand(strSql, connection);
                command.Parameters.AddWithValue("@UserId", httpContext.Session.GetString("uid"));
                command.Parameters.AddWithValue("@receive", receiverId);
                if (!string.IsNullOrEmpty(receiverId))
                {
                    command.Parameters.AddWithValue("@ReceiverId", receiverId);
                }

                await connection.OpenAsync();
                using (var reader = await command.ExecuteReaderAsync())
                {
                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync())
                        {
                            string Uid = httpContext.Session.GetString("uid");
                            if (Uid == null)
                            {
                                continue;
                            }
                            chatMessages.Add(new Messages
                            {
                                Id = reader.GetInt32(0),
                                SenderId = reader.GetString(1),
                                ReceiverId = reader.GetString(2),
                                Message = reader.GetString(3),
                                Timestamp = reader.GetDateTime(4).ToString("yyyy-MM-dd HH:mm:ss"),
                                Type = reader.GetString(1) == Uid ? "deliver" : "receive",
                                sendToID = receiverId,
                                UserName = reader.GetString(1)== Uid? reader.GetString(8):reader.GetString(7),
                                Image = reader.GetString(9),
                                BookName = reader.GetString(10),
                                BookStatus = reader.GetString(11),
                                BookID = reader.IsDBNull(5) ? 0 : reader.GetInt32(5),
                                OrderID = reader.IsDBNull(6) ? 0 : reader.GetInt32(6),
                                Place = reader.IsDBNull(12) ? "" : reader.GetString(12),
                                IsCheckOrder = reader.IsDBNull(13) ? "" : reader.GetString(13),
                            });
                        }
                    }  
                }
            }
            return chatMessages;
        }

        public async Task<List<dynamic>> GetList()
        {
            var httpContext = Context.GetHttpContext();
            string ConnStr = _configuration.GetConnectionString("Database")
                     ?? throw new InvalidOperationException("Connection string 'Database' not found.");
            List<object> messageList = new List<object>();

            string strSql = @"
                                WITH RankedMessages AS (
                                SELECT 
                                    Messages.Id,
                                    Messages.SenderId,
                                    Messages.ReceiverId,
                                    Messages.Message,
                                    Messages.Timestamp,
                                    ROW_NUMBER() OVER (
                                        PARTITION BY 
                                            CASE 
                                                WHEN Messages.SenderId < Messages.ReceiverId THEN Messages.SenderId ELSE Messages.ReceiverId 
                                            END,
                                            CASE 
                                                WHEN Messages.SenderId < Messages.ReceiverId THEN Messages.ReceiverId ELSE Messages.SenderId 
                                            END
                                        ORDER BY Messages.Timestamp DESC
                                    ) AS RowNum
                                FROM Messages
                                WHERE Messages.SenderId = @UserId OR Messages.ReceiverId = @UserId
                            )
                            SELECT 
                                RankedMessages.Id,
                                RankedMessages.SenderId,
                                Sender.Name AS SenderName, -- 發送者的名稱
                                RankedMessages.ReceiverId,
                                Receiver.Name AS ReceiverName, -- 接收者的名稱
                                RankedMessages.Message,
                                RankedMessages.Timestamp
                            FROM RankedMessages
                            LEFT JOIN Users AS Sender ON RankedMessages.SenderId = Sender.Id
                            LEFT JOIN Users AS Receiver ON RankedMessages.ReceiverId = Receiver.Id
                            WHERE RankedMessages.RowNum = 1;";

            using (var connection = new SqlConnection(ConnStr))
            {
                var command = new SqlCommand(strSql, connection);
                command.Parameters.AddWithValue("@UserId", httpContext.Session.GetString("uid"));

                await connection.OpenAsync();
                using (var reader = await command.ExecuteReaderAsync())
                {
                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync())
                        {
                            messageList.Add(new
                            {
                                Id = reader.GetInt32(0),
                                SenderId = reader.GetString(1),
                                ReceiverId = reader.GetString(3)== httpContext.Session.GetString("uid") ? reader.GetString(1): reader.GetString(3),
                                Name = reader.GetString(1)== httpContext.Session.GetString("uid")? reader.GetString(4): reader.GetString(2),
                                Message = reader.IsDBNull(5) ? null : reader.GetString(5),
                                timestamp = reader.GetDateTime(6).ToString("yyyy-MM-dd HH:mm:ss"),
                                myuid = httpContext.Session.GetString("uid")
                            });
                        }
                    }
                }
            }
            return messageList;
        }
    }
}