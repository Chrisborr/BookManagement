﻿using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using static System.Reflection.Metadata.BlobBuilder;
namespace BookMangement.Models
{
    public class DBmanager
    {
        private readonly string ConnStr;
        public DBmanager(IConfiguration configuration)
        {
            //連線字串
            ConnStr = configuration.GetConnectionString("Database")
                     ?? throw new InvalidOperationException("Connection string 'Database' not found.");
        }
        //找出書籍
        public List<Books> GetBooks(string type)
        {
            List<Books> Books = new List<Books>();
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(ConnStr))
                {
                    string strsql = @"select * from Book where isnull(sold,'') <> 'Y' and isnull(isCheck,'') <> 'N' ";
                    if (type != "All")
                    {
                        strsql += " and  Status = @Status";
                    }
                    using (SqlCommand sqlCommand = new SqlCommand(strsql, sqlConnection))
                    {
                        if (type != "All")
                        {
                            sqlCommand.Parameters.Add(new SqlParameter("@Status", type));
                        }
                        sqlConnection.Open();

                        using (SqlDataReader reader = sqlCommand.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Books book = new Books
                                    {
                                        Id = reader.GetInt32(0),
                                        User_Id = reader.GetInt32(1),
                                        Title = reader.GetString(2),
                                        Author = reader.GetString(3),
                                        Condition = reader.GetString(4),
                                        Price = reader.GetInt32(5),
                                        Category = reader.GetString(6),
                                        Status = reader.GetString(7),
                                        Image = reader.IsDBNull(8) ? null : reader.GetString(8)
                                    };
                                    Books.Add(book);
                                }
                            }
                            else
                            {
                                Console.WriteLine("查無書籍");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }

            return Books;
        }
        //管理員待上架書籍
        public List<Books> GetConfirmedBooks()
        {
            List<Books> Books = new List<Books>();
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(ConnStr))
                {
                    string strsql = @"select * from Book where isnull(isCheck,'') <> 'Y' ";

                    using (SqlCommand sqlCommand = new SqlCommand(strsql, sqlConnection))
                    {
                        sqlConnection.Open();

                        using (SqlDataReader reader = sqlCommand.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Books book = new Books
                                    {
                                        Id = reader.GetInt32(0),
                                        User_Id = reader.GetInt32(1),
                                        Title = reader.GetString(2),
                                        Author = reader.GetString(3),
                                        Condition = reader.GetString(4),
                                        Price = reader.GetInt32(5),
                                        Category = reader.GetString(6),
                                        Status = reader.GetString(7),
                                        Image = reader.IsDBNull(8) ? null : reader.GetString(8)
                                    };
                                    Books.Add(book);
                                }
                            }
                            else
                            {
                                Console.WriteLine("查無書籍");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }

            return Books;
        }
        //書籍管理
        public List<Books> GetBookManage(string userID)
        {
            List<Books> Books = new List<Books>();
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(ConnStr))
                {
                    string strsql = @"select * from Book where  User_Id=@User_Id";

                    using (SqlCommand sqlCommand = new SqlCommand(strsql, sqlConnection))
                    {
                        sqlCommand.Parameters.Add(new SqlParameter("@User_Id", userID));
                        sqlConnection.Open();

                        using (SqlDataReader reader = sqlCommand.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Books book = new Books
                                    {
                                        Id = reader.GetInt32(0),
                                        User_Id = reader.GetInt32(1),
                                        Title = reader.GetString(2),
                                        Author = reader.GetString(3),
                                        Condition = reader.GetString(4),
                                        Price = reader.GetInt32(5),
                                        Category = reader.GetString(6),
                                        Status = reader.GetString(7),
                                        Image = reader.IsDBNull(8) ? null : reader.GetString(8)
                                    };
                                    Books.Add(book);
                                }
                            }
                            else
                            {
                                Console.WriteLine("查無書籍");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }

            return Books;
        }
        //搜尋書籍
        public List<Books> QueryBook(string BookTitle)
        {
            List<Books> Books = new List<Books>();
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(ConnStr))
                {
                    string strsql = @"select * from Book where Title like @Title";
                    using (SqlCommand sqlCommand = new SqlCommand(strsql, sqlConnection))
                    {
                        sqlCommand.Parameters.Add(new SqlParameter("@Title", "%" + BookTitle + "%"));
                        sqlConnection.Open();

                        using (SqlDataReader reader = sqlCommand.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Books book = new Books
                                    {
                                        Id = reader.GetInt32(0),
                                        User_Id = reader.GetInt32(1),
                                        Title = reader.GetString(2),
                                        Author = reader.GetString(3),
                                        Condition = reader.GetString(4),
                                        Price = reader.GetInt32(5),
                                        Category = reader.GetString(6),
                                        Status = reader.GetString(7),
                                        Image = reader.IsDBNull(8) ? null : reader.GetString(8)
                                    };
                                    Books.Add(book);
                                }
                            }
                            else
                            {
                                Console.WriteLine("查無書籍");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }

            return Books;
        }
        //新增書籍
        public void Creat(Books books)
        {
            SqlConnection sqlConnection = new SqlConnection(ConnStr);
            SqlCommand sqlCommand = new SqlCommand(
                @"insert into Book(User_Id,Title,Author,Condition,Price,Category,Status,Image,Introduction,Memo,IsCheck)
                  values(@User_Id,@Title,@Author,@Condition,@Price,@Category,@Status,@Image,@Introduction,@Memo,@IsCheck) select @@identity");
            sqlCommand.Connection = sqlConnection;
            sqlCommand.Parameters.Add(new SqlParameter("@User_Id", "123"));
            sqlCommand.Parameters.Add(new SqlParameter("@Title", books.Title == null ? DBNull.Value : books.Title));
            sqlCommand.Parameters.Add(new SqlParameter("@Author", books.Author == null ? DBNull.Value : books.Author));
            sqlCommand.Parameters.Add(new SqlParameter("@Condition", books.Condition));
            sqlCommand.Parameters.Add(new SqlParameter("@Price", books.Price));
            sqlCommand.Parameters.Add(new SqlParameter("@Category", books.Category == null ? DBNull.Value : books.Category));
            sqlCommand.Parameters.Add(new SqlParameter("@Status", books.Status == null ? DBNull.Value : books.Status));
            sqlCommand.Parameters.Add(new SqlParameter("@Image", books.Image == null ? DBNull.Value : books.Image));
            sqlCommand.Parameters.Add(new SqlParameter("@Introduction", books.Introduction == null ? DBNull.Value : books.Introduction));
            sqlCommand.Parameters.Add(new SqlParameter("@Memo", books.Memo == null ? DBNull.Value : books.Memo));
            sqlCommand.Parameters.Add(new SqlParameter("@IsCheck", "N"));
            try
            {
                sqlConnection.Open();
                var result = sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                Console.WriteLine("錯誤: " + ex.Message);
            }
        }
        //新增收藏
        public int? CreatCollect(string UserID,Books books)
        {
            SqlConnection sqlConnection = new SqlConnection(ConnStr);
            SqlCommand sqlCommand = new SqlCommand(
                @"insert into Collect(Book_Id,User_Id)
                      values(@Book_Id,@User_Id)
                       select @@identity");
            sqlCommand.Connection = sqlConnection;
            sqlCommand.Parameters.Add(new SqlParameter("@User_Id", UserID));
            sqlCommand.Parameters.Add(new SqlParameter("@Book_Id", books.Id));

            try
            {
                sqlConnection.Open();
                var result = sqlCommand.ExecuteScalar();

                // 將結果轉換為整數類型
                return result != null ? Convert.ToInt32(result) : (int?)null;
            }
            catch (Exception ex)
            {
                Console.WriteLine("錯誤: " + ex.Message);
                return null; // 如果發生錯誤，返回 null
            }
        }
        //聊天室訊息
        public async Task<int> CreatMessageAsync(string selfID, string sendToID, string message,int BookID,int OrderID)
        {
            using (SqlConnection sqlConnection = new SqlConnection(ConnStr))
            {
                string strSql = @"
                    INSERT INTO Messages (SenderId, ReceiverId, Message, Timestamp,BookID,OrderID)
                    VALUES (@SelfID, @SendToID, @Message, @Timestamp,@BookID,@OrderID);
                    SELECT SCOPE_IDENTITY();";
                SqlCommand sqlCommand = new SqlCommand(strSql);
                sqlCommand.Connection = sqlConnection;
                sqlCommand.Parameters.AddWithValue("@SelfID", selfID);
                sqlCommand.Parameters.AddWithValue("@SendToID", sendToID ?? (object)DBNull.Value); // 處理空值
                sqlCommand.Parameters.AddWithValue("@Message", message);
                sqlCommand.Parameters.AddWithValue("@Timestamp", DateTime.Now);
                sqlCommand.Parameters.AddWithValue("@BookID", BookID);
                sqlCommand.Parameters.AddWithValue("@OrderID", OrderID);

                await sqlConnection.OpenAsync();
                var result = await sqlCommand.ExecuteScalarAsync();
                return Convert.ToInt32(result);
            }
        }

        public int? CreatOrder(int BookID,string Place,string Memo,int UserID,string uid, string Status, string Payment,string RentDate="")
        {
            SqlConnection sqlConnection = new SqlConnection(ConnStr);
            SqlCommand sqlCommand = new SqlCommand(
                @"insert into [Transaction](User_Id,Book_Id,Time,Type,Seller_ID,Place,Memo,Payment,IsCheckOrder,RentDate)
                      values(@User_Id,@Book_Id,@Time,@Type,@Seller_ID,@Place,@Memo,@Payment,@IsCheckOrder,@RentDate)
                       select @@identity");
            sqlCommand.Connection = sqlConnection;
            sqlCommand.Parameters.Add(new SqlParameter("@User_Id", uid));
            sqlCommand.Parameters.Add(new SqlParameter("@Book_Id", BookID));
            sqlCommand.Parameters.Add(new SqlParameter("@Time", DateTime.Now));
            sqlCommand.Parameters.Add(new SqlParameter("@Type", Status));
            sqlCommand.Parameters.Add(new SqlParameter("@Seller_ID", UserID));
            sqlCommand.Parameters.Add(new SqlParameter("@Place", string.IsNullOrEmpty(Place) ? DBNull.Value : Place));
            sqlCommand.Parameters.Add(new SqlParameter("@Memo", string.IsNullOrEmpty(Memo) ? DBNull.Value : Memo));
            sqlCommand.Parameters.Add(new SqlParameter("@Payment", Payment));
            sqlCommand.Parameters.Add(new SqlParameter("@IsCheckOrder", "N"));
            sqlCommand.Parameters.Add(new SqlParameter("@RentDate", string.IsNullOrEmpty(RentDate) ? DBNull.Value : RentDate));
            try
            {
                sqlConnection.Open();
                var result = sqlCommand.ExecuteScalar();

                // 將結果轉換為整數類型
                return result != null ? Convert.ToInt32(result) : (int?)null;
            }
            catch (Exception ex)
            {
                Console.WriteLine("錯誤: " + ex.Message);
                return null; // 如果發生錯誤，返回 null
            }
        }
    }
}
