﻿using System.Security.Cryptography;
using System.Text;

namespace BookMangement.Models
{
    public class AESEncryption
    {
        public string Encrypt(string plainText, string key, string iv)
        {
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Encoding.UTF8.GetBytes(key.PadRight(32, ' ')); // 密钥是 32 字节
                aesAlg.IV = Encoding.UTF8.GetBytes(iv.PadRight(16, ' ')); // 初始化向量是 16 字节

                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(cs))
                        {
                            sw.Write(plainText); // 写入待加密数据
                        }
                    }

                    // 返回 Base64 编码的加密结果
                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }
        // AES 解密方法
        public string Decrypt(string cipherText, string key, string iv)
        {
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Encoding.UTF8.GetBytes(key.PadRight(32, ' ')); // 密钥是 32 字节
                aesAlg.IV = Encoding.UTF8.GetBytes(iv.PadRight(16, ' ')); // 初始化向量是 16 字节

                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream ms = new MemoryStream(Convert.FromBase64String(cipherText)))
                {
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader sr = new StreamReader(cs))
                        {
                            return sr.ReadToEnd(); // 返回解密后的明文
                        }
                    }
                }
            }
        }
    }
}
