﻿using BookMangement.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Net;

namespace BookMangement.Controllers
{
    public class ManageController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _configuration;

        public ManageController(ILogger<HomeController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }
        public IActionResult Index()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")) || HttpContext.Session.GetString("uid")!="1")
            {
                TempData["message"] = "您沒有權限!";
                return RedirectToAction("Login", "Home");
            }

            DBmanager dbManager = new DBmanager(_configuration);
            List<Books> books = dbManager.GetConfirmedBooks();
            ViewBag.title = "所有書籍 All";
            return View(books);
        }
        public IActionResult Check(int Bookid)
        {
            string ConnStr = _configuration.GetConnectionString("Database")
                                        ?? throw new InvalidOperationException("Connection string 'Database' not found.");
            string strSql = @"
                            update Book set IsCheck='Y'
                            where id=@BookID";

            using (var connection = new SqlConnection(ConnStr))
            {
                // 建立 SQL 指令
                var command = new SqlCommand(strSql, connection);
                command.Parameters.AddWithValue("@BookID", Bookid);

                try
                {
                    connection.Open(); // 開啟資料庫連接

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        TempData["message"] = "上架成功";
                        return RedirectToAction("Index", "Manage");
                    }
                    else
                    {
                        TempData["message"] = "失敗";
                        return RedirectToAction("Index", "Manage");
                    }
                }
                catch (Exception ex)
                {
                    //錯誤處理
                    TempData["message"] = $"失敗: {ex.Message}";
                }
            }
            return RedirectToAction("Index", "Manage");
        }
    }
}
