using BookMangement.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Net.Mail;
using System.Net;
using System.Text;
using Microsoft.Extensions.Configuration;
using System.Xml.Linq;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Http;
using static System.Reflection.Metadata.BlobBuilder;
using System.Transactions;
using System.Data;
using Microsoft.Identity.Client;

namespace BookMangement.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _configuration;

        public HomeController(ILogger<HomeController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }
        //����
        public IActionResult Index()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "�Х��n�J!";
                return RedirectToAction("Login", "Home");
            }
            string ConnStr = _configuration.GetConnectionString("Database")
                                        ?? throw new InvalidOperationException("Connection string 'Database' not found.");
            DBmanager dbmanager = new DBmanager(_configuration);
            string strSql = @"
                                  select *
                                  from [Transaction]
                                  where IsUserComplete='Y'
                                  and IsSellerComplete='Y'
                                  and (User_Id =@UserID or Seller_ID=@UserID)";

            using (var connection = new SqlConnection(ConnStr))
            {
                // �إ� SQL ���O
                var command = new SqlCommand(strSql, connection);
                command.Parameters.AddWithValue("@UserID", HttpContext.Session.GetString("uid"));
                try
                {
                    connection.Open(); // �}�Ҹ�Ʈw�s��

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        string checkOrderStatusSql = @"
                        select *
                        from Feedback
                        where OrderID = @OrderID
                        and UserID=@UserID";

                        using (var checkConnection = new SqlConnection(ConnStr))
                        {
                            var checkCommand = new SqlCommand(checkOrderStatusSql, checkConnection);
                            checkCommand.Parameters.AddWithValue("@OrderID", reader["Id"].ToString());
                            checkCommand.Parameters.AddWithValue("@UserID", HttpContext.Session.GetString("uid"));

                            try
                            {
                                checkConnection.Open(); // �}�Ҹ�Ʈw�s��
                                SqlDataReader checkReader = checkCommand.ExecuteReader();
                                if (checkReader.Read())
                                {
                                    
                                }
                                else
                                {
                                    return RedirectToAction("FormFilling", "Book", new { OrderId = reader["Id"].ToString() });
                                }
                            }
                            catch (Exception ex)
                            {
                                // ���~�B�z
                                TempData["message"] = $"�q���ˬd����: {ex.Message}";
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    //���~�B�z
                    TempData["message"] = $"����: {ex.Message}";
                }
            }

            string type = "All";
            DBmanager dbManager = new DBmanager(_configuration);
            List<Books> books = dbManager.GetBooks(type);
            ViewBag.title = "�Ҧ����y All";
            return View(books);
        }
        [HttpPost]
        public IActionResult Index(string type)
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "�Х��n�J!";
                return RedirectToAction("Login", "Home");
            }
            List<Books> books = new List<Books>();
            string BookTitle = "";
            if (type == "Search")
            {
                BookTitle = Request.Form["BookTitle"];
                DBmanager dbManager = new DBmanager(_configuration);
                books = dbManager.QueryBook(BookTitle);
                if (books == null || books.Count == 0)
                {
                    ViewBag.Message = "�S�����ŦX�����y�A�Э��s�j���I";
                    ViewBag.title = "�d�L���y";
                    return View();
                }
            }
            else
            {
                DBmanager dbManager = new DBmanager(_configuration);
                books = dbManager.GetBooks(type);
            }
            if (type == "All")
            {
                ViewBag.title = "�Ҧ����y All";
            }
            else if(type == "Transaction")
            {
                ViewBag.title = "������y Transaction";
            }
            else if (type == "Exchange")
            {
                ViewBag.title = "�洫���y Exchange";
            }
            else if (type == "Rent")
            {
                ViewBag.title = "������y Rent";
            }
            else if (type == "Search")
            {
                if (BookTitle == "")
                {
                    ViewBag.title = "�Ҧ����y All";
                }
                else
                {
                    ViewBag.title = $"���y�W��: {BookTitle}";
                }
            }
            return View(books); //�^�ǵ��G
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(string Account,string Password)
        {

            string ConnStr = _configuration.GetConnectionString("Database")
                                        ?? throw new InvalidOperationException("Connection string 'Database' not found.");
            DBmanager dbmanager = new DBmanager(_configuration);
            string strSql = @"
                                select Id
                                from Users
                                where Account=@Account
                                and Password=@Password";

            using (var connection = new SqlConnection(ConnStr))
                {
                    // �إ� SQL ���O
                    var command = new SqlCommand(strSql, connection);
                    command.Parameters.AddWithValue("@Account", Account);
                    AESEncryption desEncryption = new AESEncryption();
                    Password = desEncryption.Encrypt(Password, "CiYnRDqtJeprdXjFFFEI2V4C4PhfRpmg", "stWbxcMSwM5cbahu");
                    command.Parameters.AddWithValue("@Password", Password);
                    try
                    {
                        connection.Open(); // �}�Ҹ�Ʈw�s��

                        SqlDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            //TempData["message"] = "�n�J���\";
                            HttpContext.Session.SetString("uid", reader["Id"].ToString());
                            if (reader["Id"].ToString() == "1")
                            {
                                return RedirectToAction("Index", "Manage");
                            }
                            return RedirectToAction("Index", "Home");
                        }
                    }
                    catch (Exception ex)
                    {
                        //���~�B�z
                        TempData["message"] = $"����: {ex.Message}";
                    }
                }
            TempData["message"] = "�b���αK�X���~";
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(string Name, string Account, string Password, string ConfirmPassword, string Email, string ConfirmEmail)
        {
            if(ConfirmEmail!= HttpContext.Session.GetString("Verify"))
            {
                TempData["message"] = "���ҽX���~�Э��s������ҽX" ;
                HttpContext.Session.Remove("Verify");
                return View();
            }
            else
            {
                HttpContext.Session.Remove("Verify");
            }
            string ConnStr = _configuration.GetConnectionString("Database")
                                        ?? throw new InvalidOperationException("Connection string 'Database' not found.");
            AESEncryption desEncryption = new AESEncryption();
            string encryptionPassword = desEncryption.Encrypt(Password, "CiYnRDqtJeprdXjFFFEI2V4C4PhfRpmg", "stWbxcMSwM5cbahu");
            SqlConnection sqlConnection = new SqlConnection(ConnStr);
            SqlCommand sqlCommand = new SqlCommand(
                @"insert into Users(Name,Account,Password,Suspension,Email)
                      values(@Name,@Account,@Password,@Suspension,@Email)
                       select @@identity");
            sqlCommand.Connection = sqlConnection;
            sqlCommand.Parameters.Add(new SqlParameter("@Name", Name));
            sqlCommand.Parameters.Add(new SqlParameter("@Account", Account));
            
            sqlCommand.Parameters.Add("@Password", SqlDbType.NVarChar).Value = encryptionPassword;
            sqlCommand.Parameters.Add(new SqlParameter("@Suspension", "N"));
            sqlCommand.Parameters.Add(new SqlParameter("@Email", Email));

            try
            {
                sqlConnection.Open();
                var result = sqlCommand.ExecuteScalar();

                if (result != null)
                {
                    int userId = Convert.ToInt32(result);
                    TempData["message"] = "���U���\" + userId;
                    return RedirectToAction("Login", "Home" );
                }
                else
                {
                    TempData["message"] = "���U����";
                    return View();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("���~: " + ex.Message);
                return View(); 
            }
        }
        [HttpPost]
        public JsonResult Verify(string Email)
        {
            try
            {
                //// �ϥ� Google Mail Server �o�H
                string GoogleID = "a3812360@gmail.com"; //Google �o�H�b��
                string TempPwd = "iwxwuipiqqolbows"; //���ε{���K�X
                string ReceiveMail = Email; //�����H�c

                string SmtpServer = "smtp.gmail.com";
                int SmtpPort = 587;
                MailMessage mms = new MailMessage();
                mms.From = new MailAddress(GoogleID);
                mms.Subject = "�q�l�H�c�{��";
                Random random = new Random();
                int randomNumber = random.Next(100000, 1000000);
                mms.Body = "�z�����ҽX��"+ randomNumber;
                HttpContext.Session.SetString("Verify", randomNumber.ToString());
                mms.IsBodyHtml = true;
                mms.SubjectEncoding = Encoding.UTF8;
                mms.To.Add(new MailAddress(ReceiveMail));
                using (SmtpClient client = new SmtpClient(SmtpServer, SmtpPort))
                {
                    client.EnableSsl = true;
                    client.Credentials = new NetworkCredential(GoogleID, TempPwd);//�H�H�b�K 
                    client.Send(mms); //�H�X�H��
                }
                return Json(new { success = true, message ="�ЦܫH�c������ҽX�����ұb��!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"�o�Ϳ��~: {ex.Message}" });
            }
        }

        public IActionResult Infromation()
        {
            string ConnStr = _configuration.GetConnectionString("Database")
                             ?? throw new InvalidOperationException("Connection string 'Database' not found.");
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "�Х��n�J!";
                return RedirectToAction("Login", "Home");
            }
            string strSql = @"
                            select * ,(select avg(Rating)from Feedback WHERE Feedback.UserID = Users.ID) as[Rating]
                            from [Users]
                            where id=@UserID";

            using (var connection = new SqlConnection(ConnStr))
            {
                // �إ� SQL ���O
                var command = new SqlCommand(strSql, connection);
                command.Parameters.AddWithValue("@UserID", HttpContext.Session.GetString("uid"));

                connection.Open(); // �}�Ҹ�Ʈw�s��

                // ����d��
                using (var reader = command.ExecuteReader())
                {
                    if (reader.HasRows && reader.Read())
                    {
                        ViewBag.UserID = reader["Id"]?.ToString();
                        ViewBag.UserName = reader["Name"]?.ToString() ?? "";
                        ViewBag.Rating = reader["Rating"].ToString();
                        ViewBag.Email = reader["Email"].ToString();
                        ViewBag.StudentNumber = reader["Email"].ToString().Substring(0,8);

                    }
                }
                return View();
            }
        }
        public IActionResult Reviews(int page = 1, int pageSize = 5)
        {
            string ConnStr = _configuration.GetConnectionString("Database")
                             ?? throw new InvalidOperationException("Connection string 'Database' not found.");

            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "�Х��n�J!";
                return RedirectToAction("Login", "Home");
            }

            string countSql = @"
                        select count(*) 
                        from Feedback
                        left join Users on Users.id = Feedback.UserID
                        left join [Transaction] on Feedback.OrderID = [Transaction].id
                        left join Book on [Transaction].Book_Id = Book.id
                        where SendID=@SendID";

            string strSql = @"
                        select Feedback.*, Users.Name as [UserName], Book.title as [BookName]
                        from Feedback
                        left join Users on Users.id = Feedback.UserID
                        left join [Transaction] on Feedback.OrderID = [Transaction].id
                        left join Book on [Transaction].Book_Id = Book.id
                        where SendID=@SendID
                        order by Feedback.Id
                        offset @Offset rows fetch next @PageSize rows only";

            using (var connection = new SqlConnection(ConnStr))
            {
                // �p���`�ƶq
                var countCommand = new SqlCommand(countSql, connection);
                countCommand.Parameters.AddWithValue("@SendID", HttpContext.Session.GetString("uid"));

                connection.Open();
                var totalCount = (int)countCommand.ExecuteScalar(); // ����`��Ƽ�

                // �p���`����
                int totalPages = (int)Math.Ceiling(totalCount / (double)pageSize);

                // �]�w�d�ߪ���ƽd��
                var command = new SqlCommand(strSql, connection);
                command.Parameters.AddWithValue("@SendID", HttpContext.Session.GetString("uid"));
                command.Parameters.AddWithValue("@Offset", (page - 1) * pageSize);
                command.Parameters.AddWithValue("@PageSize", pageSize);

                var feedbackList = new List<FeedbackViewModel>();

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        feedbackList.Add(new FeedbackViewModel
                        {
                            Id = reader["Id"]?.ToString(),
                            BookName = reader["BookName"]?.ToString() ?? "",
                            UserName = reader["UserName"]?.ToString() ?? "",
                            Rating = int.TryParse(reader["Rating"]?.ToString(), out var rating) ? rating : 0,
                            Status = reader["Status"]?.ToString() ?? "",
                            Feedback = reader["FeedbackText"]?.ToString() ?? "",
                        });
                    }
                }

                // �ǻ���ƨ� View
                ViewBag.Feedbacks = feedbackList;
                ViewBag.CurrentPage = page;
                ViewBag.TotalPages = totalPages;

                return View();
            }
        }
        public IActionResult UserRecord()
        {
            return View();
        }
        [HttpPost]
        public IActionResult UserRecord(string Mode)
        {
            string ConnStr = _configuration.GetConnectionString("Database")
                             ?? throw new InvalidOperationException("Connection string 'Database' not found.");

            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "�Х��n�J!";
                return RedirectToAction("Login", "Home");
            }
            string strSql = @"
                        select *,Book.id as [BookID]
                        from [Transaction]
                        left join Book on [Transaction].Book_Id = Book.id";
            if (Mode== "Seller")
            {
                strSql += " where Seller_ID = @SellerID";
            }
            else
            {
                strSql += " where [Transaction].User_ID = @UserID";
            }
            using (var connection = new SqlConnection(ConnStr))
            {
                // �إ� SQL ���O
                var command = new SqlCommand(strSql, connection);
                if(Mode == "Seller")
                {
                    command.Parameters.AddWithValue("@SellerID", HttpContext.Session.GetString("uid"));
                }
                else
                {
                    command.Parameters.AddWithValue("@UserID", HttpContext.Session.GetString("uid"));
                }

                connection.Open(); // �}�Ҹ�Ʈw�s��
                List<object> records = new();
                // ����d��
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        records.Add(new
                        {
                            UserId = reader["Id"]?.ToString(),
                            BookName = reader["title"]?.ToString() ?? "",
                            BookID = reader["BookID"]?.ToString() ?? "",
                        });
                    }
                }
                return Json(new { success = true, data = records });
            }
        }
    }
}
