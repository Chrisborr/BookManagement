﻿using BookMangement.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System;
using System.Net;
using System.Net.Http;
using static System.Reflection.Metadata.BlobBuilder;

namespace BookMangement.Controllers
{
    public class BookController : Controller
    {
        private readonly ILogger<BookController> _logger;
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _environment;
        public BookController(ILogger<BookController> logger, IConfiguration configuration, IWebHostEnvironment environment)
        {
            _logger = logger;
            _configuration = configuration;
            _environment = environment;
        }

        public IActionResult Creat()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "請先登入!";
                return RedirectToAction("Login", "Home");
            }
            return View();
        }
        [HttpPost]
        public IActionResult Creat(Books books, IFormFile myimg)
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "請先登入!";
                return RedirectToAction("Login", "Home");
            }
            if (ModelState.IsValid || ModelState.ContainsKey("Image"))
            {
                if (myimg != null && myimg.Length > 0)
                {
                    string uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
                    string uniqueFileName = Guid.NewGuid().ToString() + "_" + myimg.FileName;
                    string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        myimg.CopyTo(fileStream);
                    }

                    // 儲存圖片路徑到資料庫
                    books.Image = uniqueFileName;
                }

                DBmanager dbmanager = new DBmanager(_configuration);
                try
                {
                    dbmanager.Creat(books);
                    ViewBag.Message = "新增成功，請等待管理員審核";
                    return RedirectToAction("Index", "Home");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                    return RedirectToAction("Index", "Home");
                }
            }

            return View(books);
        }
        public IActionResult Collect()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "請先登入!";
                return RedirectToAction("Login", "Home");
            }
            string ConnStr = _configuration.GetConnectionString("Database")
                             ?? throw new InvalidOperationException("Connection string 'Database' not found.");
            string strSql = "";
            strSql = @"
                        SELECT *
                        from Collect
                        left join Book on Book.id = Book_Id
                        where Collect.User_Id = @User_Id";
            List<BookCollection> collections = new List<BookCollection>();
            using (var connection = new SqlConnection(ConnStr))
                {
                    // 建立 SQL 指令
                    var command = new SqlCommand(strSql, connection);
                    command.Parameters.AddWithValue("@User_Id", HttpContext.Session.GetString("uid"));

                    connection.Open(); // 開啟資料庫連接

                    // 執行查詢
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            collections.Add(new BookCollection
                            {
                                BookName = reader["Title"]?.ToString(),
                                Author = reader["Author"]?.ToString(),
                                Status = reader["Status"]?.ToString(),
                                UID = reader["uid"]?.ToString(),
                            });
                        }
                    }
                }
            return View(collections);
        }
        [HttpPost]
        public JsonResult Collect(int bookId)
        {
            try
            {
                DBmanager dbmanager = new DBmanager(_configuration);
                Books book = new Books { Id = bookId };
                var newId = dbmanager.CreatCollect(HttpContext.Session.GetString("uid"),book);

                if (newId.HasValue)
                {
                    return Json(new { success = true, message = "已加入收藏!" });
                }
                else
                {
                    return Json(new { success = false, message = "收藏操作失敗!" });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"發生錯誤: {ex.Message}" });
            }
        }
        public IActionResult Message()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "請先登入!";
                return RedirectToAction("Login", "Home");
            }
            return View();
        }
        public IActionResult Contact(int Userid, int Bookid)
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "請先登入!";
                return RedirectToAction("Login", "Home");
            }
            // 取得資料庫連接字串
            string ConnStr = _configuration.GetConnectionString("Database")
                             ?? throw new InvalidOperationException("Connection string 'Database' not found.");

            string strSql = @"
                            SELECT 
                                Book.Title AS BookName, 
                                Users.Name AS UserName,
                                Image,
                                Status,
                                Price
                            FROM Book
                            LEFT JOIN Users ON Book.User_Id = Users.Id
                            WHERE Book.Id = @BookId";

            using (var connection = new SqlConnection(ConnStr))
            {
                // 建立 SQL 指令
                var command = new SqlCommand(strSql, connection);
                command.Parameters.AddWithValue("@BookId", Bookid);

                connection.Open(); // 開啟資料庫連接

                // 執行查詢
                using (var reader = command.ExecuteReader())
                {
                    if (reader.HasRows && reader.Read())
                    {
                        ViewBag.BookName = reader["BookName"]?.ToString() ?? "未知書名";
                        ViewBag.UserName = reader["UserName"]?.ToString() ?? "未知使用者";
                        ViewBag.Image = reader["Image"]?.ToString() ?? "";
                        if (reader["Status"].ToString()== "Transaction")
                        {
                            ViewBag.Status = "交易";
                        }
                        else if (reader["Status"].ToString() == "Exchange")
                        {
                            ViewBag.Status = "交換";
                        }
                        else if (reader["Status"].ToString() == "Rent")
                        {
                            ViewBag.Status = "租賃";
                        }
                        ViewBag.Price = reader["Price"]?.ToString() ?? "";
                    }
                    else
                    {
                        ViewBag.BookName = "未知書名";
                        ViewBag.UserName = "未知使用者";
                    }
                }
            }
            ViewBag.UserId = Userid;
            ViewBag.BookId = Bookid;

            return View();
        }
        public IActionResult AddOrder()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "請先登入!";
                return RedirectToAction("Login", "Home");
            }
            string BookID = Request.Query["bookID"];
            string Mode = Request.Query["Mode"];
            string ConnStr = _configuration.GetConnectionString("Database")
                             ?? throw new InvalidOperationException("Connection string 'Database' not found.");
            string strSql = "";
            if (Mode == "Edit")
            {
                string orderId = Request.Query["orderId"];
                strSql = @"
                            SELECT 
                                [Transaction].Id,
                                Book.Title AS BookName, 
                                Book.Image,
                                [Transaction].Type,
                                [Transaction].Payment,
                                Place,
	                            [Transaction].Memo
                            FROM [Transaction]
                            LEFT JOIN Book ON Book.Id = [Transaction].Book_Id
                            WHERE [Transaction].Id = @OrderId";

                using (var connection = new SqlConnection(ConnStr))
                {
                    // 建立 SQL 指令
                    var command = new SqlCommand(strSql, connection);
                    command.Parameters.AddWithValue("@OrderId", orderId);

                    connection.Open(); // 開啟資料庫連接

                    // 執行查詢
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.HasRows && reader.Read())
                        {
                            ViewBag.BookName = reader["BookName"]?.ToString() ?? "未知書名";
                            ViewBag.Image = reader["Image"]?.ToString() ?? "";
                            ViewBag.Status = reader["Type"].ToString();
                            ViewBag.Price = reader["Payment"]?.ToString() ?? "0";
                            ViewBag.OrderId = reader["Id"]?.ToString();
                            ViewData["Place"] = reader["Place"]?.ToString();
                            ViewData["Memo"] = reader["Memo"]?.ToString() ?? "";
                            ViewData["Mode"] = "Edit";
                        }
                    }
                }
            }
            else
            {
                strSql = @"
                            SELECT 
                                Book.Title AS BookName, 
                                Users.Name AS UserName,
                                Image,
                                Status,
                                Price,
                                User_Id
                            FROM Book
                            LEFT JOIN Users ON Book.User_Id = Users.Id
                            WHERE Book.Id = @BookId";

                using (var connection = new SqlConnection(ConnStr))
                {
                    // 建立 SQL 指令
                    var command = new SqlCommand(strSql, connection);
                    command.Parameters.AddWithValue("@BookId", BookID);

                    connection.Open(); // 開啟資料庫連接

                    // 執行查詢
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.HasRows && reader.Read())
                        {
                            ViewBag.BookID = BookID;
                            ViewBag.BookName = reader["BookName"]?.ToString() ?? "未知書名";
                            ViewBag.UserName = reader["UserName"]?.ToString() ?? "未知使用者";
                            ViewBag.Image = reader["Image"]?.ToString() ?? "";
                            ViewBag.Status = reader["Status"].ToString();
                            ViewBag.Price = reader["Price"]?.ToString() ?? "0";
                            ViewBag.UserID = reader["User_Id"]?.ToString() ?? "0";
                        }
                    }
                }
            }
            return View();
        }
        [HttpPost]
        public IActionResult AddOrder(int BookId,string Place,string Memo,int UserID,string Status, string Payment,string RentDate)
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "請先登入!";
                return RedirectToAction("Login", "Home");
            }
            DBmanager dbmanager = new DBmanager(_configuration);
           try
           {
                var OrderID = dbmanager.CreatOrder(BookId, Place, Memo, UserID, HttpContext.Session.GetString("uid"), Status, Payment, RentDate);
                int orderIDValue = OrderID.Value;
                dbmanager.CreatMessageAsync(HttpContext.Session.GetString("uid"), UserID.ToString(), "已發送交易請求", BookId, orderIDValue);
                TempData["message"] = "新增成功!";
                return RedirectToAction("AddOrder", "Book", new { orderId = OrderID, Mode = "Edit" });
            }
           catch (Exception e)
           {
                Console.WriteLine(e.ToString());
                return RedirectToAction("Index", "Home");
           }
        }
        public IActionResult ConfirmOrder()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "請先登入!";
                return RedirectToAction("Login", "Home");
            }
            string ConnStr = _configuration.GetConnectionString("Database")
                                        ?? throw new InvalidOperationException("Connection string 'Database' not found.");
            DBmanager dbmanager = new DBmanager(_configuration);
            string Mode = Request.Query["Mode"];
            string OrderId = Request.Query["OrderId"];
            string BookID = Request.Query["BookID"];
            string UserID = Request.Query["UserID"];
            if(Mode == "accept")
            {
                string strSql = @"
                            update [Transaction] set IsCheckOrder='Y'
                            where Id = @OrderId";

                using (var connection = new SqlConnection(ConnStr))
                {
                    // 建立 SQL 指令
                    var command = new SqlCommand(strSql, connection);
                    command.Parameters.AddWithValue("@OrderId", OrderId);

                    try
                    {
                        connection.Open(); // 開啟資料庫連接

                        int rowsAffected = command.ExecuteNonQuery(); 

                        if (rowsAffected > 0)
                        {
                            // 刪除成功
                            TempData["message"] = "訂單已確認";
                            dbmanager.CreatMessageAsync(HttpContext.Session.GetString("uid"), UserID.ToString(), "已接受交易請求", int.Parse(BookID) , int.Parse(OrderId));
                        }
                        else
                        {
                            //沒有找到該訂單
                            TempData["message"] = "找不到該訂單";
                        }
                    }
                    catch (Exception ex)
                    {
                        //錯誤處理
                        TempData["message"] = $"失敗: {ex.Message}";
                    }
                }
            }
            else
            {
                string strSql = @"
                            delete from [Transaction]
                            where Id = @OrderId";

                using (var connection = new SqlConnection(ConnStr))
                {
                    // 建立 SQL 指令
                    var command = new SqlCommand(strSql, connection);
                    command.Parameters.AddWithValue("@OrderId", OrderId);

                    try
                    {
                        connection.Open(); // 開啟資料庫連接

                        // 執行刪除命令
                        int rowsAffected = command.ExecuteNonQuery(); // 使用 ExecuteNonQuery 來執行刪除操作

                        if (rowsAffected > 0)
                        {
                            // 刪除成功
                            TempData["message"] = "訂單已成功刪除!";
                            dbmanager.CreatMessageAsync(HttpContext.Session.GetString("uid"), UserID.ToString(), "已拒絕交易請求", 0, 0);
                        }
                        else
                        {
                            //沒有找到該訂單
                            TempData["message"] = "找不到該訂單，刪除失敗!";
                        }
                    }
                    catch (Exception ex)
                    {
                        //錯誤處理
                        TempData["message"] = $"刪除失敗: {ex.Message}";
                    }
                }
            }
            return RedirectToAction("Index", "Home");
        }
        public IActionResult CancelOrder(int OrderId, int BookId, int UserID)
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "請先登入!";
                return RedirectToAction("Login", "Home");
            }
            string ConnStr = _configuration.GetConnectionString("Database")
                                         ?? throw new InvalidOperationException("Connection string 'Database' not found.");
            DBmanager dbmanager = new DBmanager(_configuration);
            string strSql = @"
                            delete from [Transaction]
                            where Id = @OrderId";

            using (var connection = new SqlConnection(ConnStr))
            {
                // 建立 SQL 指令
                var command = new SqlCommand(strSql, connection);
                command.Parameters.AddWithValue("@OrderId", OrderId);

                try
                {
                    connection.Open(); // 開啟資料庫連接

                    // 執行刪除命令
                    int rowsAffected = command.ExecuteNonQuery(); // 使用 ExecuteNonQuery 來執行刪除操作

                    if (rowsAffected > 0)
                    {
                        // 刪除成功
                        TempData["message"] = "訂單已成功刪除!";
                        dbmanager.CreatMessageAsync(HttpContext.Session.GetString("uid"), UserID.ToString(), "已取消交易請求", BookId, OrderId);
                    }
                    else
                    {
                        //沒有找到該訂單
                        TempData["message"] = "找不到該訂單，刪除失敗!";
                    }
                }
                catch (Exception ex)
                {
                    //錯誤處理
                    TempData["message"] = $"刪除失敗: {ex.Message}";
                }
            }
            return RedirectToAction("Index","Home");
        }

        public IActionResult CompleteOrder()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "請先登入!";
                return RedirectToAction("Login", "Home");
            }
            string ConnStr = _configuration.GetConnectionString("Database")
                                        ?? throw new InvalidOperationException("Connection string 'Database' not found.");
            DBmanager dbmanager = new DBmanager(_configuration);
            string Mode = Request.Query["Mode"];
            string OrderId = Request.Query["OrderId"];
            string BookID = Request.Query["BookID"];
            string Seller_ID = "";
            string User_Id = "";


            string strSql = @"
                                select Seller_ID,User_Id
                                from [Transaction]
                                where Id=@OrderID";

            using (var connection = new SqlConnection(ConnStr))
            {
                // 建立 SQL 指令
                var command = new SqlCommand(strSql, connection);
                command.Parameters.AddWithValue("@OrderID", OrderId);
                try
                {
                    connection.Open(); // 開啟資料庫連接

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Seller_ID = reader["Seller_ID"].ToString();
                        User_Id = reader["User_Id"].ToString();
                    }
                }
                catch (Exception ex)
                {
                    //錯誤處理
                    TempData["message"] = $"失敗: {ex.Message}";
                }
            }
            

            if (Mode == "accept")
            {
                if (Seller_ID == HttpContext.Session.GetString("uid"))
                {
                    strSql = @"
                            update [Transaction] set IsSellerComplete='Y'
                            where Id = @OrderId";
                }
                else
                {
                    strSql = @"
                            update [Transaction] set IsUserComplete='Y'
                            where Id = @OrderId";
                }
                using (var connection = new SqlConnection(ConnStr))
                {
                    // 建立 SQL 指令
                    var command = new SqlCommand(strSql, connection);
                    command.Parameters.AddWithValue("@OrderId", OrderId);

                    try
                    {
                        connection.Open(); // 開啟資料庫連接

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            // 刪除成功
                            TempData["message"] = "完成訂單確認";
                            if (Seller_ID == HttpContext.Session.GetString("uid"))
                            {
                                dbmanager.CreatMessageAsync(HttpContext.Session.GetString("uid"), HttpContext.Session.GetString("uid") == Seller_ID ? User_Id : Seller_ID , "賣方完成訂單確認", int.Parse(BookID), int.Parse(OrderId));
                            }
                            else
                            {
                                dbmanager.CreatMessageAsync(HttpContext.Session.GetString("uid"), HttpContext.Session.GetString("uid") == Seller_ID ? User_Id : Seller_ID, "買方完成訂單確認", int.Parse(BookID), int.Parse(OrderId));
                            }
                        }
                        else
                        {
                            //沒有找到該訂單
                            TempData["message"] = "訂單失效";
                        }
                    }
                    catch (Exception ex)
                    {
                        //錯誤處理
                        TempData["message"] = $"失敗: {ex.Message}";
                    }
                }
            }
            else
            {
                if (Seller_ID == HttpContext.Session.GetString("uid"))
                {
                    strSql = @"
                            update [Transaction] set IsSellerComplete='N'
                            where Id = @OrderId";
                }
                else
                {
                    strSql = @"
                            update [Transaction] set IsUserComplete='N'
                            where Id = @OrderId";
                }
                using (var connection = new SqlConnection(ConnStr))
                {
                    // 建立 SQL 指令
                    var command = new SqlCommand(strSql, connection);
                    command.Parameters.AddWithValue("@OrderId", OrderId);

                    try
                    {
                        connection.Open(); // 開啟資料庫連接

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            // 刪除成功
                            TempData["message"] = "未確認訂單";
                            if (Seller_ID == HttpContext.Session.GetString("uid"))
                            {
                                dbmanager.CreatMessageAsync(HttpContext.Session.GetString("uid"), HttpContext.Session.GetString("uid") == Seller_ID ? User_Id : Seller_ID, "賣方未完成訂單確認", int.Parse(BookID), int.Parse(OrderId));
                            }
                            else
                            {
                                dbmanager.CreatMessageAsync(HttpContext.Session.GetString("uid"), HttpContext.Session.GetString("uid") == Seller_ID ? User_Id : Seller_ID, "買方未完成訂單確認", int.Parse(BookID), int.Parse(OrderId));
                            }
                        }
                        else
                        {
                            //沒有找到該訂單
                            TempData["message"] = "訂單失效";
                        }
                    }
                    catch (Exception ex)
                    {
                        //錯誤處理
                        TempData["message"] = $"失敗: {ex.Message}";
                    }
                }
            }


            strSql = @"
                        select IsUserComplete,IsSellerComplete
                               from [Transaction]
                               where Id=@OrderID";

            using (var connection = new SqlConnection(ConnStr))
            {
                // 建立 SQL 指令
                var command = new SqlCommand(strSql, connection);
                command.Parameters.AddWithValue("@OrderID", OrderId);
                try
                {
                    connection.Open(); // 開啟資料庫連接

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        if(reader["IsUserComplete"].ToString()=="Y"&& reader["IsSellerComplete"].ToString() == "Y")
                        {
                            strSql = @"
                                    update [Book]
                                    set sold = 'Y'
                                    where Id = @BookID";

                            var updateCommand = new SqlCommand(strSql, connection);
                            updateCommand.Parameters.AddWithValue("@BookID", BookID);

                            int rowsAffected = updateCommand.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                            }
                            else
                            {
                            }
                        }
                        
                    }
                }
                catch (Exception ex)
                {
                    //錯誤處理
                    TempData["message"] = $"失敗: {ex.Message}";
                }
            }

            return RedirectToAction("Message", "Book");
        }

        public IActionResult FormFilling(string OrderId,string SendID)
        {
            if(OrderId == null)
            {
                TempData["OrderId"] = Request.Query["OrderId"];
                TempData["SendID"] = Request.Query["SendID"];
            }
            return View();
        }
        [HttpPost]
        public IActionResult FormFilling(string OrderID ,string source, string usage, string satisfaction, int rating, string book_method, string feedback,string SendID)
        {
            string ConnStr = _configuration.GetConnectionString("Database")
                                         ?? throw new InvalidOperationException("Connection string 'Database' not found.");
            using (SqlConnection sqlConnection = new SqlConnection(ConnStr))
            {
                sqlConnection.Open();

                string query = @"
                    INSERT INTO Feedback (Source, Usage, Satisfaction, Rating, Status, FeedbackText, OrderID, UserID,SendID)
                    VALUES (@Source, @Usage, @Satisfaction, @Rating, @Status, @FeedbackText, @OrderID, @UserID,@SendID);
                    SELECT @@IDENTITY;";

                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    // 替換參數值
                    sqlCommand.Parameters.Add(new SqlParameter("@Source", source ?? (object)DBNull.Value));
                    sqlCommand.Parameters.Add(new SqlParameter("@Usage", usage ?? (object)DBNull.Value));
                    sqlCommand.Parameters.Add(new SqlParameter("@Satisfaction", satisfaction ?? (object)DBNull.Value));
                    sqlCommand.Parameters.Add(new SqlParameter("@Rating", rating));
                    sqlCommand.Parameters.Add(new SqlParameter("@Status", book_method ?? (object)DBNull.Value));
                    sqlCommand.Parameters.Add(new SqlParameter("@FeedbackText", feedback ?? (object)DBNull.Value));
                    sqlCommand.Parameters.Add(new SqlParameter("@OrderID", OrderID ?? (object)DBNull.Value));
                    sqlCommand.Parameters.Add(new SqlParameter("@UserID", HttpContext.Session.GetString("uid")));
                    sqlCommand.Parameters.Add(new SqlParameter("@SendID", SendID ?? (object)DBNull.Value));

                    // 執行 SQL 命令並返回插入的 ID
                    int feedbackId = Convert.ToInt32(sqlCommand.ExecuteScalar());
                }
            }
            return View();
        }
        [HttpPost]
        public IActionResult RemoveCollection(int id)
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "請先登入!";
                return RedirectToAction("Login", "Home");
            }

            string ConnStr = _configuration.GetConnectionString("Database")
                             ?? throw new InvalidOperationException("Connection string 'Database' not found.");

            // SQL 刪除語句
            string strSql = "DELETE FROM Collect WHERE uid = @Id";

            using (var connection = new SqlConnection(ConnStr))
            {
                var command = new SqlCommand(strSql, connection);
                command.Parameters.AddWithValue("@Id", id);

                connection.Open();
                int affectedRows = command.ExecuteNonQuery();

                if (affectedRows > 0)
                {
                    return Json(new { success = true });
                }
                else
                {
                    return Json(new { success = false });
                }
            }
        }

        public IActionResult Details(int id,string Mode) {
            string ConnStr = _configuration.GetConnectionString("Database")
                             ?? throw new InvalidOperationException("Connection string 'Database' not found.");
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "請先登入!";
                return RedirectToAction("Login", "Home");
            }
            string strSql = @"
                            select * ,(select avg(Rating)from Feedback WHERE Feedback.UserID = Book.User_Id ) as[Rating]
                            from Book
                            where id=@BookID";

            using (var connection = new SqlConnection(ConnStr))
            {
                // 建立 SQL 指令
                var command = new SqlCommand(strSql, connection);
                command.Parameters.AddWithValue("@BookID", id);

                connection.Open(); // 開啟資料庫連接

                // 執行查詢
                using (var reader = command.ExecuteReader())
                {
                    if (reader.HasRows && reader.Read())
                    {
                        ViewBag.BookID = reader["Id"]?.ToString();
                        ViewBag.UserID = reader["User_Id"]?.ToString();
                        ViewBag.BookName = reader["Title"]?.ToString() ?? "未知書名";
                        ViewBag.Image = reader["Image"]?.ToString() ?? "";
                        ViewBag.Status = reader["Status"].ToString();
                        ViewBag.Price = reader["Price"]?.ToString() ?? "0";
                        ViewBag.Author = reader["Author"]?.ToString();
                        ViewBag.Condition = reader["Condition"]?.ToString();
                        ViewBag.Category = reader["Category"]?.ToString();
                        ViewBag.Introduction = reader["Introduction"]?.ToString();
                        ViewBag.Memo = reader["Memo"]?.ToString();
                        ViewBag.Rating = reader["Rating"].ToString();
                        ViewBag.Mode = Mode;
                    }
                }
                return View();
            }
        }

        public IActionResult Manage()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("uid")))
            {
                TempData["message"] = "您沒有權限!";
                return RedirectToAction("Login", "Home");
            }

            DBmanager dbManager = new DBmanager(_configuration);
            List<Books> books = dbManager.GetBookManage(HttpContext.Session.GetString("uid"));
            ViewBag.title = "所有書籍 All";
            return View(books);
        }
    }
}
